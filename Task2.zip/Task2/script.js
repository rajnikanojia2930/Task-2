// Form Validation
document.getElementById("form").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name");
  const email = document.getElementById("email");
  const message = document.getElementById("form-message");

  if (!name.value.trim()) {
    message.textContent = "Name is required.";
    return;
  }

  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!email.value.match(emailPattern)) {
    message.textContent = "Please enter a valid email address.";
    return;
  }

  message.style.color = "green";
  message.textContent = "Form submitted successfully!";
  name.value = "";
  email.value = "";
});

// To-Do List
function addTask() {
  const taskInput = document.getElementById("taskInput");
  const taskList = document.getElementById("taskList");
  const taskText = taskInput.value.trim();

  if (taskText === "") return;

  const li = document.createElement("li");
  li.innerHTML = `${taskText} <button onclick="removeTask(this)">X</button>`;
  taskList.appendChild(li);

  taskInput.value = "";
}

function removeTask(btn) {
  const li = btn.parentElement;
  li.remove();
}
